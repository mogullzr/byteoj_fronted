#!/usr/bin/env bash
set -e

SOURCE_DIR="$(cd "$(dirname "$0")" && pwd)"
INSTALL_DIR="$HOME/.local/share/byteoj-phone-bridge"
SERVICE_DIR="$HOME/.config/systemd/user"
AUTOSTART_DIR="$HOME/.config/autostart"
LOG_DIR="$HOME/.local/state/byteoj-phone-bridge"
ARCHITECTURE="$(uname -m)"
case "$ARCHITECTURE" in
  x86_64|amd64) BRIDGE_BINARY="byteoj-phone-bridge-linux-amd64" ;;
  aarch64|arm64) BRIDGE_BINARY="byteoj-phone-bridge-linux-arm64" ;;
  *) echo "暂不支持当前处理器架构：$ARCHITECTURE"; exit 1 ;;
esac

mkdir -p "$INSTALL_DIR" "$LOG_DIR"
cp "$SOURCE_DIR/$BRIDGE_BINARY" "$INSTALL_DIR/byteoj-phone-bridge"
chmod 755 "$INSTALL_DIR/byteoj-phone-bridge"
rm -f "$INSTALL_DIR/phone_bridge.py"

if command -v systemctl >/dev/null 2>&1 && systemctl --user show-environment >/dev/null 2>&1; then
  mkdir -p "$SERVICE_DIR"
  sed \
    -e "s|__BRIDGE_EXECUTABLE__|$INSTALL_DIR/byteoj-phone-bridge|g" \
    "$SOURCE_DIR/byteoj-phone-bridge.service.template" > "$SERVICE_DIR/byteoj-phone-bridge.service"
  systemctl --user daemon-reload
  systemctl --user enable --now byteoj-phone-bridge.service
else
  mkdir -p "$AUTOSTART_DIR"
  sed \
    -e "s|__BRIDGE_EXECUTABLE__|$INSTALL_DIR/byteoj-phone-bridge|g" \
    "$SOURCE_DIR/byteoj-phone-bridge.desktop.template" > "$AUTOSTART_DIR/byteoj-phone-bridge.desktop"
  nohup "$INSTALL_DIR/byteoj-phone-bridge" > "$LOG_DIR/output.log" 2> "$LOG_DIR/error.log" &
fi

sleep 1
if ! command -v curl >/dev/null 2>&1 || curl -fsS http://127.0.0.1:8767/health >/dev/null; then
  echo "安装成功：ByteOJ 手机相机桥接已启动，并会在登录时自动运行。"
else
  echo "安装完成，但桥接暂时没有响应。日志目录：$LOG_DIR"
  exit 1
fi
