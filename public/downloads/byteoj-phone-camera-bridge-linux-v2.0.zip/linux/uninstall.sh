#!/usr/bin/env bash

INSTALL_DIR="$HOME/.local/share/byteoj-phone-bridge"
SERVICE_PATH="$HOME/.config/systemd/user/byteoj-phone-bridge.service"
AUTOSTART_PATH="$HOME/.config/autostart/byteoj-phone-bridge.desktop"

if command -v systemctl >/dev/null 2>&1; then
  systemctl --user disable --now byteoj-phone-bridge.service >/dev/null 2>&1 || true
fi
pkill -f "$INSTALL_DIR/byteoj-phone-bridge" >/dev/null 2>&1 || true
rm -f "$SERVICE_PATH" "$AUTOSTART_PATH"
rm -rf "$INSTALL_DIR"

if command -v systemctl >/dev/null 2>&1; then
  systemctl --user daemon-reload >/dev/null 2>&1 || true
fi
echo "ByteOJ 手机相机桥接已卸载。"
