ByteOJ 手机高清相机桥接 - Linux

安装：
1. 解压整个压缩包。
2. 在解压目录打开终端。
3. 执行：chmod +x install.sh uninstall.sh
4. 执行：./install.sh
5. 安装成功后返回考试页面，输入手机应用显示的地址并连接。

卸载：执行 ./uninstall.sh。

要求：常见 64 位桌面 Linux、最新版 Chrome 或 Edge。无需安装 Python、Java 或 Node。
手机与电脑必须在同一个局域网，手机 ByteOJ 高清相机应用需保持前台运行。
