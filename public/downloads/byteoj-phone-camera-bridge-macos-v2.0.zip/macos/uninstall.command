#!/bin/zsh

INSTALL_DIR="$HOME/Library/Application Support/ByteOJPhoneBridge"
PLIST_PATH="$HOME/Library/LaunchAgents/com.mogullzr.byteoj-phone-bridge.plist"

launchctl bootout "gui/$(id -u)" "$PLIST_PATH" 2>/dev/null || true
rm -f "$PLIST_PATH"
rm -rf "$INSTALL_DIR"

echo "ByteOJ 手机相机桥接已卸载。"
read -k 1 "?按任意键关闭..."
