#!/bin/zsh
set -e

SOURCE_DIR="${0:A:h}"
INSTALL_DIR="$HOME/Library/Application Support/ByteOJPhoneBridge"
PLIST_PATH="$HOME/Library/LaunchAgents/com.mogullzr.byteoj-phone-bridge.plist"
LOG_DIR="$HOME/Library/Logs/ByteOJPhoneBridge"

mkdir -p "$INSTALL_DIR" "$HOME/Library/LaunchAgents" "$LOG_DIR"
cp "$SOURCE_DIR/byteoj-phone-bridge" "$INSTALL_DIR/byteoj-phone-bridge"
chmod 755 "$INSTALL_DIR/byteoj-phone-bridge"
rm -f "$INSTALL_DIR/phone_bridge.py"
xattr -d com.apple.quarantine "$INSTALL_DIR/byteoj-phone-bridge" 2>/dev/null || true

sed \
  -e "s|__BRIDGE_EXECUTABLE__|$INSTALL_DIR/byteoj-phone-bridge|g" \
  -e "s|__LOG_DIR__|$LOG_DIR|g" \
  "$SOURCE_DIR/com.mogullzr.byteoj-phone-bridge.plist.template" > "$PLIST_PATH"

launchctl bootout "gui/$(id -u)" "$PLIST_PATH" 2>/dev/null || true
launchctl bootstrap "gui/$(id -u)" "$PLIST_PATH"
launchctl enable "gui/$(id -u)/com.mogullzr.byteoj-phone-bridge"

sleep 1
if curl -fsS http://127.0.0.1:8767/health >/dev/null; then
  echo "安装成功：ByteOJ 手机相机桥接已启动，并会在登录时自动运行。"
  echo "现在可以返回考试页面连接手机相机。"
else
  echo "安装完成，但桥接暂时没有响应。日志位置：$LOG_DIR/error.log"
fi

read -k 1 "?按任意键关闭..."
