ByteOJ 手机高清相机桥接 - macOS

安装：
1. 解压整个压缩包。
2. 双击 install.command。
3. 若系统阻止打开，请右键 install.command 后选择“打开”。
4. 安装成功后返回考试页面，输入手机应用显示的地址并连接。

卸载：双击 uninstall.command。

要求：macOS 11 或更高版本、最新版 Chrome 或 Edge。无需安装 Python、Java 或 Node。
手机与电脑必须在同一个局域网，手机 ByteOJ 高清相机应用需保持前台运行。
