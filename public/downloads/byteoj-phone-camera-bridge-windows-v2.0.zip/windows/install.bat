@echo off
chcp 65001 >nul
setlocal

set "SOURCE_DIR=%~dp0"
set "INSTALL_DIR=%LOCALAPPDATA%\ByteOJPhoneBridge"
set "BRIDGE_BINARY=byteoj-phone-bridge-windows-amd64.exe"
if /I "%PROCESSOR_ARCHITECTURE%"=="ARM64" set "BRIDGE_BINARY=byteoj-phone-bridge-windows-arm64.exe"
if /I "%PROCESSOR_ARCHITEW6432%"=="ARM64" set "BRIDGE_BINARY=byteoj-phone-bridge-windows-arm64.exe"

if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
copy /Y "%SOURCE_DIR%%BRIDGE_BINARY%" "%INSTALL_DIR%\byteoj-phone-bridge.exe" >nul
copy /Y "%SOURCE_DIR%start_bridge.vbs" "%INSTALL_DIR%\start_bridge.vbs" >nul
del /Q "%INSTALL_DIR%\phone_bridge.py" "%INSTALL_DIR%\python-path.txt" >nul 2>nul

powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-Process 'byteoj-phone-bridge' -ErrorAction SilentlyContinue | Stop-Process -Force" >nul 2>nul
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "ByteOJPhoneBridge" /t REG_SZ /d "wscript.exe \"%INSTALL_DIR%\start_bridge.vbs\"" /f >nul
start "" wscript.exe "%INSTALL_DIR%\start_bridge.vbs"

timeout /t 2 /nobreak >nul
powershell -NoProfile -Command "try { $r = Invoke-RestMethod -Uri 'http://127.0.0.1:8767/health' -TimeoutSec 3; if ($r.ok) { exit 0 } }; exit 1"
if %errorlevel%==0 (
  echo 安装成功：ByteOJ 手机相机桥接已启动，并会在登录时自动运行。
) else (
  echo 安装完成，但桥接暂时没有响应。请确认安全软件没有阻止 ByteOJ 手机相机桥接。
)

pause
