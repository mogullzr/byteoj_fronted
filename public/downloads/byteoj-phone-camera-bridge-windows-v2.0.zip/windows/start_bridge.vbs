Option Explicit

Dim fileSystem, shell, installDir, bridgeExecutable
Set fileSystem = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

installDir = fileSystem.GetParentFolderName(WScript.ScriptFullName)
bridgeExecutable = fileSystem.BuildPath(installDir, "byteoj-phone-bridge.exe")

If Not fileSystem.FileExists(bridgeExecutable) Then WScript.Quit 1

shell.Run Chr(34) & bridgeExecutable & Chr(34), 0, False
