@echo off
chcp 65001 >nul

set "INSTALL_DIR=%LOCALAPPDATA%\ByteOJPhoneBridge"
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "ByteOJPhoneBridge" /f >nul 2>nul
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-Process 'byteoj-phone-bridge' -ErrorAction SilentlyContinue | Stop-Process -Force" >nul 2>nul
rmdir /S /Q "%INSTALL_DIR%" 2>nul

echo ByteOJ 手机相机桥接已卸载。
pause
