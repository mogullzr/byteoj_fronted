ByteOJ 手机高清相机桥接 - Windows

安装：
1. 解压整个压缩包，不要在压缩包预览中直接运行。
2. 双击 install.bat，无需管理员权限。
3. 若 Windows 安全提示询问是否允许运行，请确认运行 ByteOJ 手机相机桥接。
4. 安装成功后返回考试页面，输入手机应用显示的地址并连接。

卸载：双击 uninstall.bat。

要求：Windows 10/11、最新版 Chrome 或 Edge。无需安装 Python、Java 或 Node。
手机与电脑必须在同一个局域网，手机 ByteOJ 高清相机应用需保持前台运行。
